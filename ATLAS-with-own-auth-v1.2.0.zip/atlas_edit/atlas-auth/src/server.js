import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import Database from 'better-sqlite3';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import nodemailer from 'nodemailer';
import { v4 as uuidv4 } from 'uuid';

const app = express();
const PORT = Number(process.env.PORT || 8080);
const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_ME_ATLAS_AUTH_SECRET';
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'victorrblx790@gmail.com';
const db = new Database(process.env.ATLAS_DB_PATH || './atlas-auth.db');

db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT,
 name TEXT NOT NULL DEFAULT '',
 provider TEXT NOT NULL DEFAULT 'password',
 photo_url TEXT NOT NULL DEFAULT '',
 role TEXT NOT NULL DEFAULT 'user',
 disabled INTEGER NOT NULL DEFAULT 0,
 created_at INTEGER NOT NULL,
 updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reset_tokens (
 token_hash TEXT PRIMARY KEY,
 user_id TEXT NOT NULL,
 expires_at INTEGER NOT NULL,
 used INTEGER NOT NULL DEFAULT 0,
 created_at INTEGER NOT NULL
);
`);

function cleanEmail(v=''){ return String(v).trim().toLowerCase(); }
function publicUser(u){ return {id:u.id,email:u.email,displayName:u.name,photoURL:u.photo_url||'',role:u.role,provider:u.provider}; }
function signToken(u){ return jwt.sign({sub:u.id,email:u.email,role:u.role}, JWT_SECRET, {expiresIn:'30d', issuer:'atlas-auth'}); }
function auth(req,res,next){
  try {
    const h=req.get('authorization')||'';
    if(!h.startsWith('Bearer ')) return res.status(401).json({code:'UNAUTHORIZED',message:'Sessão não encontrada.'});
    const p=jwt.verify(h.slice(7),JWT_SECRET,{issuer:'atlas-auth'});
    const u=db.prepare('SELECT * FROM users WHERE id=?').get(p.sub);
    if(!u||u.disabled) return res.status(401).json({code:'UNAUTHORIZED',message:'Conta inválida ou desativada.'});
    req.user=u; next();
  } catch { return res.status(401).json({code:'UNAUTHORIZED',message:'Sessão expirada. Entre novamente.'}); }
}

let mailer=null;
if(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS){
  mailer=nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||465),secure:String(process.env.SMTP_SECURE||'true')==='true',auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}});
}
async function notify(subject,text){
  if(!mailer) return;
  try{ await mailer.sendMail({from:process.env.SMTP_USER,to:ADMIN_EMAIL,subject,text}); }catch(e){ console.error('email notification failed',e.message); }
}
async function sendResetEmail(to,name,token){
  if(!mailer) return false;
  const base=(process.env.PUBLIC_AUTH_URL||'').replace(/\/$/,'');
  const link=`${base}/reset.html?token=${encodeURIComponent(token)}`;
  try{ await mailer.sendMail({from:process.env.SMTP_USER,to,subject:'Redefinição de senha — ATLAS',text:`Olá ${name||''},\n\nUse este link para redefinir sua senha da ATLAS:\n${link}\n\nO link expira em 30 minutos. Se você não pediu isso, ignore este e-mail.`}); return true; }catch(e){console.error('reset email failed',e.message);return false;}
}

app.use(helmet({contentSecurityPolicy:false}));
app.use(cors({origin:true,credentials:false}));
app.use(express.json({limit:'32kb'}));
app.use(rateLimit({windowMs:15*60*1000,max:120,standardHeaders:true,legacyHeaders:false}));
app.get('/health',(req,res)=>res.json({ok:true,service:'ATLAS Auth',time:new Date().toISOString()}));

app.post('/auth/register', async (req,res)=>{
  const name=String(req.body?.name||'').trim().slice(0,80), email=cleanEmail(req.body?.email), password=String(req.body?.password||'');
  if(!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({code:'INVALID_EMAIL',message:'Digite um e-mail válido.'});
  if(password.length<8) return res.status(400).json({code:'WEAK_PASSWORD',message:'A senha precisa ter pelo menos 8 caracteres.'});
  if(db.prepare('SELECT id FROM users WHERE email=?').get(email)) return res.status(409).json({code:'EMAIL_EXISTS',message:'Este e-mail já está cadastrado.'});
  const now=Date.now(), id=uuidv4(), hash=await bcrypt.hash(password,12);
  const role=email===cleanEmail(ADMIN_EMAIL)?'admin':'user';
  db.prepare('INSERT INTO users(id,email,password_hash,name,provider,role,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').run(id,email,hash,name,'password',role,now,now);
  await notify('Novo cadastro na ATLAS',`Novo usuário cadastrado.\nNome: ${name}\nE-mail: ${email}\nID: ${id}\nData: ${new Date(now).toISOString()}`);
  const u=db.prepare('SELECT * FROM users WHERE id=?').get(id);
  res.status(201).json({token:signToken(u),user:publicUser(u)});
});

app.post('/auth/login', async (req,res)=>{
  const email=cleanEmail(req.body?.email), password=String(req.body?.password||'');
  const u=db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if(!u || u.disabled || !u.password_hash || !(await bcrypt.compare(password,u.password_hash))) return res.status(401).json({code:'INVALID_CREDENTIALS',message:'Seu e-mail ou senha estão incorretos.'});
  res.json({token:signToken(u),user:publicUser(u)});
});

app.get('/auth/me',auth,(req,res)=>res.json({user:publicUser(req.user)}));
app.post('/auth/logout',(req,res)=>res.json({ok:true}));

app.post('/auth/forgot', async (req,res)=>{
  const email=cleanEmail(req.body?.email), u=db.prepare('SELECT * FROM users WHERE email=?').get(email);
  // Deliberately generic to avoid account enumeration.
  if(u){
    const raw=crypto.randomBytes(32).toString('hex'), hash=crypto.createHash('sha256').update(raw).digest('hex'), expires=Date.now()+30*60*1000;
    db.prepare('INSERT INTO reset_tokens(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)').run(hash,u.id,expires,Date.now());
    await sendResetEmail(u.email,u.name,raw);
  }
  res.json({ok:true,code:'RESET_SENT',message:'Se houver uma conta associada a este e-mail, enviaremos as instruções de recuperação.'});
});

app.post('/auth/reset', async (req,res)=>{
  const token=String(req.body?.token||''), password=String(req.body?.password||'');
  if(token.length<32) return res.status(400).json({code:'RESET_INVALID',message:'O link de recuperação é inválido ou expirou.'});
  if(password.length<8) return res.status(400).json({code:'WEAK_PASSWORD',message:'A senha precisa ter pelo menos 8 caracteres.'});
  const hash=crypto.createHash('sha256').update(token).digest('hex');
  const row=db.prepare('SELECT * FROM reset_tokens WHERE token_hash=? AND used=0 AND expires_at>?').get(hash,Date.now());
  if(!row) return res.status(400).json({code:'RESET_INVALID',message:'O link de recuperação é inválido ou expirou.'});
  const ph=await bcrypt.hash(password,12);
  db.prepare('UPDATE users SET password_hash=?,provider=\'password\',updated_at=? WHERE id=?').run(ph,Date.now(),row.user_id);
  db.prepare('UPDATE reset_tokens SET used=1 WHERE token_hash=?').run(hash);
  res.json({ok:true});
});

function adminOnly(req,res,next){ if(req.user?.role!=='admin') return res.status(403).json({code:'FORBIDDEN',message:'Acesso administrativo negado.'}); next(); }
app.get('/admin/users',auth,adminOnly,(req,res)=>{ const rows=db.prepare('SELECT id,email,name,provider,role,disabled,created_at,updated_at FROM users ORDER BY created_at DESC').all(); res.json({users:rows}); });
app.get('/admin/stats',auth,adminOnly,(req,res)=>{ const row=db.prepare('SELECT COUNT(*) total, SUM(CASE WHEN disabled=0 THEN 1 ELSE 0 END) active FROM users').get(); res.json({total:Number(row.total||0),active:Number(row.active||0)}); });

app.delete('/auth/account',auth,async(req,res)=>{
  const u=req.user;
  db.prepare('DELETE FROM reset_tokens WHERE user_id=?').run(u.id);
  db.prepare('DELETE FROM users WHERE id=?').run(u.id);
  await notify('Conta excluída na ATLAS',`A conta ${u.email} foi excluída. ID: ${u.id}`);
  res.json({ok:true});
});

app.get('/',(req,res)=>res.json({service:'ATLAS Auth',status:'online'}));
app.listen(PORT,()=>console.log(`ATLAS Auth listening on :${PORT}`));
