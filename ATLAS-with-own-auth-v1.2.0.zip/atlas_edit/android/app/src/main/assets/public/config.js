// ATLAS Auth endpoint. Set this to the HTTPS URL of the deployed atlas-auth service.
window.ATLAS_AUTH_CONFIG={endpoint:""};
window.ATLAS_CONFIG={
  dify:{url:"https://api.dify.ai/v1",key:""},
  image:{model:"gemini-3.1-flash-image"}
};
window.ATLAS_IMAGE_CONFIG={apiKey:"",model:"gemini-3.1-flash-image",endpoint:"https://generativelanguage.googleapis.com/v1beta/interactions"};
window.ATLAS_CALENDAR_CONFIG={apiKey:""};
window.ATLAS_LINE_CONFIG={channelId:"",shareEnabled:true};
window.ATLAS_AGENT_CONFIG={endpoint:""};
